﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AppCadCandidato.RegrasDeNegocio;

namespace AppCadCandidato.Contexto
{
    internal class Registro
    {
        public static List<Candidato> cadastro = new List<Candidato>();
    }
}
