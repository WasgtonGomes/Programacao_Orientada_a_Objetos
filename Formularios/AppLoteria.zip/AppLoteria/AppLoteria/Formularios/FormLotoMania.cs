﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLoteria.Formularios
{
    public partial class FormLotoMania : System.Windows.Forms.Form
    {
        public FormLotoMania()
        {
            InitializeComponent();
        }

        private void FormLotoMania_Load(object sender, EventArgs e)
        {

        }
    }
}
