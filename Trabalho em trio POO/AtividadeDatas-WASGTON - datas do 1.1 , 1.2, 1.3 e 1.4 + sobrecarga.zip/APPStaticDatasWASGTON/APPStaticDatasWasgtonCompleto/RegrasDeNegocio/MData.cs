﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APPStaticDatas.RegrasDeNegocio
{
    internal static class MDatas
    {
        public static int CalcularIdade(string dataNasc)
        {
            // 00/00/000
            int dia = Convert.ToInt32(dataNasc.Substring(0, 2));
            int mes = Convert.ToInt32(dataNasc.Substring(3, 2));
            int ano = Convert.ToInt32(dataNasc.Substring(6, 4));


            DateTime dataN = new DateTime(ano, mes, dia);
            DateTime dataHoje = DateTime.Now;

            TimeSpan diferenca = dataHoje - dataN;

            int idade = (int)(diferenca.Days / 365.2425);
            int meses= (int)(diferenca.Days / 30.436875);
            int dias = diferenca.Days ;
            string msg = idade + " ano(s), "+(meses - (idade * 12) + "meses e "+ dias) +" de Vida";

            return idade;

        }

        public static string CalcularTempoVida(string dataNasc)
        {
            // 00/00/000
            int dia = Convert.ToInt32(dataNasc.Substring(0, 2));
            int mes = Convert.ToInt32(dataNasc.Substring(3, 2));
            int ano = Convert.ToInt32(dataNasc.Substring(6, 4));


            DateTime dataN = new DateTime(ano, mes, dia);
            DateTime dataHoje = DateTime.Now;

            TimeSpan diferenca = dataHoje - dataN;

            int idade = (int)((diferenca.Days +1 )/ 365.2425);
            int meses = (int)((diferenca.Days+ 1) / 30.436875);
            int dias = diferenca.Days - (int)(meses*30.436875)-1;


           // string msg = idade + " ano(s), " + (meses - (idade * 12)) + "meses e " + dias  + " dias de Vida";
            string msg = meses  + "meses "+ "  de Vida";

            return msg;

        }


        // ################################ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ Atividade em trio WASGTON 1.1 , 1.2, 1.3  e 1.4 ABAIXO ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓ ⇓  ##################################



        
        public static string CalcularTempoAnos(string dataNasc)
        {
            // 00/00/000
            int dia = Convert.ToInt32(dataNasc.Substring(0, 2));
            int mes = Convert.ToInt32(dataNasc.Substring(3, 2));
            int ano = Convert.ToInt32(dataNasc.Substring(6, 4));


            DateTime dataN = new DateTime(ano, mes, dia);
            DateTime dataHoje = DateTime.Now;

            TimeSpan diferenca = dataHoje - dataN;

            int idade = (int)((diferenca.Days + 1) / 365.2425);
            


            string msg = idade + " anos " + "  de Vida";

            return msg;

        }

        public static string CalcularTempoAnos(double dataNasc)
        {
            // 00000000  valor
            // 01234567  posições
          
            int p = dataNasc.ToString().Length -8;// Responsável por tratar o erro no caso do usuário inserir valor do dia que inicice com zero (0), pois para variaveis do tipo double, int, long e demais desconsidera o zero a esquerda como nulo não adcionando possição para o mesmo.


            int dia1 = Convert.ToInt32(dataNasc.ToString().Substring(0, 2+p));
            int mes1 = Convert.ToInt32(dataNasc.ToString().Substring(2+p, 2));
            int ano1 = Convert.ToInt32(dataNasc.ToString().Substring(4+p ));


            DateTime dataN = new DateTime(ano1, mes1, dia1);
            DateTime dataHoje = DateTime.Now;

            TimeSpan diferenca = dataHoje - dataN;

            int idade = (int)((diferenca.Days + 1) / 365.2425);


            string msg = idade + " anos ";

            return msg;

        }


        public static string CalcularTempoMes(string dataNasc)
        {
            // 00/00/000
            int dia = Convert.ToInt32(dataNasc.Substring(0, 2));
            int mes = Convert.ToInt32(dataNasc.Substring(3, 2));
            int ano = Convert.ToInt32(dataNasc.Substring(6, 4));


            DateTime dataN = new DateTime(ano, mes, dia);
            DateTime dataHoje = DateTime.Now;

            TimeSpan diferenca = dataHoje - dataN;

            
            int meses = (int)((diferenca.Days + 1) / 30.436875);
           
           
            string msg = meses + " meses " + "  de Vida";

            return msg;

        }

        public static string CalcularTempoMes(double dataNasc)
        {
            // 00/00/000

            int p = dataNasc.ToString().Length - 8; // Responsável por tratar o erro no caso do usuário inserir valor do dia que inicice com zero (0), pois para variaveis do tipo double, int, long e demais desconsidera o zero a esquerda como nulo não adcionando possição para o mesmo.
            

            int dia = Convert.ToInt32(dataNasc.ToString().Substring(0, 2+p));
            int mes = Convert.ToInt32(dataNasc.ToString().Substring(2+p, 2));
            int ano = Convert.ToInt32(dataNasc.ToString().Substring(4+p));
            


            DateTime dataN = new DateTime(ano,mes, dia);
            DateTime dataHoje = DateTime.Now;

            TimeSpan diferenca = dataHoje - dataN;


            int meses = (int)((diferenca.Days + 1) / 30.436875);

            string msg = meses + " meses " ;

            return msg;

        }

        public static string CalcularSomaDeDias(string data01,string data02)
        {
           

            int dia01 = Convert.ToInt32(data01.Substring(0, 2));
            int mes01 = Convert.ToInt32(data01.Substring(3, 2));
            int ano01 = Convert.ToInt32(data01.Substring(6, 4));

            int dia02 = Convert.ToInt32(data02.Substring(0, 2));
            int mes02 = Convert.ToInt32(data02.Substring(3, 2));
            int ano02 = Convert.ToInt32(data02.Substring(6, 4));

            DateTime primeiraData = new DateTime(ano01, mes01, dia01);
            DateTime segundaData = new DateTime(ano02, mes02, dia02);

            TimeSpan diferenca = (primeiraData - segundaData);


            if (primeiraData>=segundaData)
            {
                 diferenca = (primeiraData -segundaData);
            }
            else
            {
                if (segundaData>primeiraData)
                {
                     diferenca = (segundaData-primeiraData);
                }
            }

            int dias = diferenca.Days ;

            string msg = dias + " dias ";

            return msg;



        }

        public static string CalcularSomaDeDias(double data01, double data02)
        {

            int p = data01.ToString().Length - 8; // Responsável por tratar o erro no caso do usuário inserir valor do dia que inicice com zero (0), pois para variaveis do tipo double, int, long e demais desconsidera o zero a esquerda como nulo não adcionando possição para o mesmo.

           

            int dia01 = Convert.ToInt32(data01.ToString().Substring(0, 2+p));
            int mes01 = Convert.ToInt32(data01.ToString().Substring(2+p, 2));
            int ano01 = Convert.ToInt32(data01.ToString().Substring(4+p));

            int dia02 = Convert.ToInt32(data02.ToString().Substring(0, 2+p));
            int mes02 = Convert.ToInt32(data02.ToString().Substring(2+p, 2));
            int ano02 = Convert.ToInt32(data02.ToString().Substring( 4+p));

            DateTime primeiraData = new DateTime(ano01, mes01, dia01);
            DateTime segundaData = new DateTime(ano02, mes02, dia02);

            TimeSpan diferenca = (primeiraData - segundaData);


            if (primeiraData >= segundaData)
            {
                diferenca = (primeiraData - segundaData);
            }
            else
            {
                if (segundaData > primeiraData)
                {
                    diferenca = (segundaData - primeiraData);
                }
            }

            int dias = diferenca.Days;

            string msg = dias + " dias ";

            return msg;



        }




        public static string SomarDiasApartirDataAtual(string dataDeFinal)
        {

            int dia01 = Convert.ToInt32(dataDeFinal.Substring(0, 2));
            int mes01 = Convert.ToInt32(dataDeFinal.Substring(3, 2));
            int ano01 = Convert.ToInt32(dataDeFinal.Substring(6, 4));

            DateTime finalParaData = new DateTime(ano01, mes01, dia01);
            DateTime dataHoje = DateTime.Now;


            TimeSpan diferenca = (finalParaData - dataHoje);


            int dias = diferenca.Days;

            string msg = dias + " dias ";

            return msg;
        }

        public static string SomarDiasApartirDataAtual(double dataDeFinal)
        {
            int p = dataDeFinal.ToString().Length - 8; // Responsável por tratar o erro no caso do usuário inserir valor do dia que inicice com zero (0), pois para variaveis do tipo double, int, long e demais desconsidera o zero a esquerda como nulo não adcionando possição para o mesmo.



            int dia01 = Convert.ToInt32(dataDeFinal.ToString().Substring(0, 2 + p));
            int mes01 = Convert.ToInt32(dataDeFinal.ToString().Substring(2 + p, 2));
            int ano01 = Convert.ToInt32(dataDeFinal.ToString().Substring(4 + p));

            DateTime finalParaData = new DateTime(ano01, mes01, dia01);
            DateTime dataHoje = DateTime.Now;


            TimeSpan diferenca = (finalParaData - dataHoje);


            int dias = diferenca.Days;

            string msg = dias + " dias ";

            return msg;
        }

    }
}
