﻿// 365.2425
// 30.436875
/* ############################### Aula dia 05/05/2022 rascunho ###########################
DateTime dataNasc = new DateTime(2002,09,02);

DateTime dataHoje =  DateTime.Now;

TimeSpan dataRe = dataHoje - dataNasc; // Qualquer calculo que envolve datas é necessário usar o TimeSpan

Console.WriteLine(dataRe.Days);

int idade = (int)(dataRe.Days/365.2425);

Console.WriteLine(idade);

int meses = (int)(dataRe.Days / 30.436875);

string res = "Têm " + idade + " anos " + (meses - (idade * 12)) + " meses de vida ";
Console.WriteLine(res);
*/


using APPStaticDatas.RegrasDeNegocio;

    
//Console.Write(" Insira a data  do tipo string neste formato --> (00/00/0000)  ");
//string usuario = Console.ReadLine();


//string anosData01 = MDatas.CalcularTempoAnos(usuario);
//string mesesData01 = MDatas.CalcularTempoMes(usuario);

//Console.WriteLine(" ");
//Console.WriteLine("Sua idade em anos é de  :  " + anosData01);
//Console.WriteLine(" ");
//Console.WriteLine("Sua idade em meses é de  :  " + mesesData01);
//Console.WriteLine(" ");


//Console.Write(" Insira a data do tipo double neste formato (20122000) ");
// double  b = Convert.ToDouble(Console.ReadLine());
// //double  b =02092002;
// //string  b = Console.ReadLine();


//string anosData = MDatas.CalcularTempoAnos (b);
//string mesesData = MDatas.CalcularTempoMes (b);

//Console.WriteLine(" ");

//Console.WriteLine("Sua idade em anos é de  :  " + anosData);
//Console.WriteLine(" ");
//Console.WriteLine("Sua idade em meses é de  :  " + mesesData);
//Console.WriteLine(" ");

//Console.WriteLine(" ");
//Console.Write(" Insira a 1ª data  do tipo string neste formato --> (00/00/0000)  ");
//string data01 = Console.ReadLine();
//Console.WriteLine(" ");

//Console.WriteLine(" ");
//Console.Write(" Insira a 2ª data  do tipo string neste formato --> (00/00/0000)  ");
//string data02 = Console.ReadLine();
//Console.WriteLine(" ");


//string somardias = MDatas.CalcularSomaDeDias(data01,data02);


//Console.WriteLine(" ");
//Console.WriteLine("A soma dos dias entre as datas informadas foram de  :  " + somardias);
//Console.WriteLine(" ");

//Console.WriteLine(" ");
//Console.ReadKey();
//Console.WriteLine(" ");
//Console.WriteLine("##################################################################################################### ");
//Console.WriteLine(" ");

//#####################################################################################################

Console.WriteLine(" ");
Console.Write(" Insira a 1ª data  do tipo double neste formato --> (00000000)  ");
double data01 = Convert.ToDouble(Console.ReadLine());
Console.WriteLine(" ");

Console.WriteLine(" ");
Console.Write(" Insira a 2ª data  do tipo double neste formato --> (00000000)  ");
double data02 = Convert.ToDouble(Console.ReadLine());
Console.WriteLine(" ");


string somardias = MDatas.CalcularSomaDeDias(data01, data02);


Console.WriteLine(" ");
Console.WriteLine("A soma dos dias entre as datas informadas foram de  :  " + somardias);
Console.WriteLine(" ");

Console.WriteLine(" ");
Console.ReadKey();
Console.WriteLine(" ");
Console.WriteLine("##################################################################################################### ");
Console.WriteLine(" ");



//#####################################################################################################

//Console.WriteLine(" ");
//Console.Write(" Insira a data final da soma  do tipo string neste formato --> (00/00/0000)  ");
//string datafinal = Console.ReadLine();
//Console.WriteLine(" ");


//string somardiasAtualFinal = MDatas.SomarDiasApartirDataAtual(datafinal);


//Console.WriteLine(" ");
//Console.WriteLine("A soma dos dias entre as datas informadas foram de  :  " + somardiasAtualFinal);
//Console.WriteLine(" ");

//Console.WriteLine(" ");
//Console.ReadKey();

//#####################################################################################################

Console.WriteLine(" ");
Console.Write(" Insira a data final da soma  do tipo double neste formato --> (00000000)  ");
double datafinal = Convert.ToDouble(Console.ReadLine());
Console.WriteLine(" ");


string somardiasAtualFinal = MDatas.SomarDiasApartirDataAtual(datafinal);


Console.WriteLine(" ");
Console.WriteLine("A soma dos dias entre a data atual e a informada foi de  :  " + somardiasAtualFinal);
Console.WriteLine(" ");

Console.WriteLine(" ");
Console.ReadKey();



